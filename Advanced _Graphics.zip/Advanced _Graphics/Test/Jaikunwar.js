//Jaikunwar Sidhu
//301055060

let Renderer, Scne, Camera, OrbitControl;
let Radius = 5, speed = 0.005, height = 25, Angle = 0;
let OrbitCircle = [];
let stats;
let Xposition=0, Yposition=0, Zposition=0;

let AmbientLight, SpotLight, PointLight, DirectionLight,
    R_AreaLight, SemiSphereLight;
const color = 0xF08080;

function init() {
    Scne = new THREE.Scene(); //Scene 
    Renderer = new THREE.WebGLRenderer({ antialias: true }); //newRenderer   
    Renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    Renderer.outputEncoding = THREE.sRGBEncoding;
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setClearColor(0x97B9BD); //Background or page color
    Renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(Renderer.domElement);
    Renderer.shadowMap.enabled = true;

}

function createGeometry() {
    Scne.add(new THREE.AxesHelper(20));


    let planeGeo = new THREE.PlaneBufferGeometry(50, 50);
    let planeMat = new THREE.MeshLambertMaterial({ color: 0x0495ED });
    let planeMesh = new THREE.Mesh(planeGeo, planeMat);
    planeMesh.receiveShadow = true;
    planeMesh.rotation.x = -0.5 * Math.PI;
    Scne.add(planeMesh);

    let torusGeo = new THREE.TorusGeometry( 5, 2.5, 16, 100 );
    let torusMat = new THREE.MeshStandardMaterial( { color: 0x0023F9 } );
    let torusmesh = new THREE.Mesh( torusGeo, torusMat );
    torusmesh.rotation.x = 55 ;
    Scne.add( torusmesh );

    let cubeGeo = new THREE.BoxGeometry(5, 20, 5 );
    let cubeMat = new THREE.MeshStandardMaterial( {color: 0x454545} );
    let cube = new THREE.Mesh( cubeGeo, cubeMat );
    cube.position.set(0,10,00);
    cubeCont = Container();
    cubeCont.add(cube)
    Scne.add( cubeCont );

    let sphereGeo = new THREE.SphereGeometry( 5, 32, 32 );
    let sphereMat = new THREE.MeshStandardMaterial( {color: 0x00FFFF} );
    let sphere = new THREE.Mesh( sphereGeo, sphereMat );
    sphere.position.set(0,24,00);
   
    let geometry = new THREE.CylinderGeometry( 6, 6, 1, 100 );
    let material = new THREE.MeshStandardMaterial( {color: 0xffff00} );
    let cylinder = new THREE.Mesh( geometry, material );
    cylinder.position.set(0,24,0);
   

    let cubeGeo1 = new THREE.BoxGeometry(1,20,1 );
    let cubeMat1 = new THREE.MeshStandardMaterial( {color: 0x454545} );
    let cube1 = new THREE.Mesh( cubeGeo1, cubeMat1);
    let cube2 = new THREE.Mesh( cubeGeo1, cubeMat1 );
    let cube3 = new THREE.Mesh( cubeGeo1, cubeMat1 );
    let cube4 = new THREE.Mesh( cubeGeo1, cubeMat1 );
    cube1.position.set(2,35,-2);
    cube2.position.set(-2,35,2);
    cube3.position.set(2,35,2);
    cube4.position.set(-2,35,-2);
    cubeCont1 = Container();
    cubeCont1.add(cube1, cube2, cube3, cube4);
    Scne.add(cubeCont1 );

    let geometry1 = new THREE.CylinderGeometry( 3, 3, 10, 100 );
    let material1 = new THREE.MeshStandardMaterial( {color: 0xffff00} );
    let cylinder1 = new THREE.Mesh( geometry1, material1 );
    cylinder1.rotation.x = 55 ;
    cylinder1.position.set(0,45,0);
    cubeCont1.add(cylinder1,sphere, cylinder);

    newcont = Container();
    newcont.add(cubeCont, cubeCont1, )
    Scne.add(newcont);
}

function Container(){
    let container = new THREE.Object3D();
    container.position.set(0, 0, 0);

    return container;
}
function createCyanBall(){
    cyanGeo = new THREE.SphereBufferGeometry(1, 50, 50);
    cyanMat = new THREE.MeshStandardMaterial({color : 0xffffff});
    cyanBall = new THREE.Mesh(cyanGeo, cyanMat);
    return cyanBall;
}



function setupCameraAndLight() {



    Camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100);
    Camera.position.set(50, 50, 50);
    Camera.lookAt(Scne.position);
   

    OrbitControl = new THREE.OrbitControls(Camera, Renderer.domElement);
    OrbitControl.update();

    AmbientLight = new THREE.AmbientLight(color, 1);
    AmbientLight.position.set(15, 50, -15)
    Scne.add(AmbientLight);

    SpotLight = new THREE.SpotLight(color, 1);
    SpotLight.castShadow = true;
    SpotLight.position.set(-15, 70, 15);
    Scne.add(SpotLight);


    PointLight = new THREE.PointLight(color, 1);
    PointLight.castShadow = true;
    PointLight.position.set(Xposition, 45, 15);
    PointLight.add(createCyanBall());
    pointCont = Container();
    pointCont.add(PointLight);
    Scne.add(pointCont);
 

    DirectionLight = new THREE.DirectionalLight(color, 1);
    DirectionLight.castShadow = true;
    DirectionLight.position.set(10, 70, 10);
    Scne.add(DirectionLight);

    R_AreaLight = new THREE.RectAreaLight(color, 1, 15, 30);
    R_AreaLight.position.set(0, 70, 40);   //Affects the boxgeometry 
    R_AreaLight.rotation.y = -0.5 * Math.PI;
    R_AreaLight.rotation.x = -0.5 * Math.PI;
    Scne.add(R_AreaLight);
    
    SemiSphereLight = new THREE.HemisphereLight(color, 0xb97a20, 1);
    SemiSphereLight.position.set(-10, 70, 20);
    Scne.add(SemiSphereLight);


   

}
function rotateCont(){
    PointLight.rotation.y = 5;
}

function setupDatGui() {
    
    control = new function () {
        this.Swivel = true;
        this.RaiseUpperArm = 0;
        this.RaiseLowerArm = 0;
    
    }
    let gui = new dat.GUI();
    gui.add(control, "RaiseUpperArm").onChange((e) => {
        cubeCont1.rotation.z += 0.1;
        
    });
    gui.add(control, "RaiseLowerArm").onChange((e) => {
        cubeCont.rotation.x +=0.1;
        
    });
    
    gui.add(control, "Swivel")


}

function render() {
        rotateCont();
       // animate();
       if(control.Swivel == true)
       {
       newcont.rotation.y +=0.1;
       }
        requestAnimationFrame(render);
        Renderer.render(Scne, Camera);
}
function animate(){
    requestAnimationFrame(animate);

    pointCont.rotation.y += 0.1;
   
    //cubeCont.rotation.x += 0.1;
}
window.onload = () => {
    init();
    setupCameraAndLight();
    createGeometry();
    animate();
    setupDatGui();
    render();
}


class ColorGUIHelper {
    constructor(object, prop) {
        this.object = object;
        this.prop = prop;
    }
    get value() {
        return `#${this.object[this.prop].getHexString()}`;
    }
    set value(hexString) {
        this.object[this.prop].set(hexString);
    }
}