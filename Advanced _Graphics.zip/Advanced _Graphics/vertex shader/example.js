//Jaikunwar Sidhu
//301055060

const clock = new THREE.Clock();
const __shader = Shaders.BasicShader9B0;

function init() {
    Renderer = new THREE.WebGLRenderer({ antialias: true });
    Scene = new THREE.Scene();
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setSize(window.innerWidth, window.innerHeight);
    Renderer.setClearColor(0x004400);
    Renderer.shadowMap.enabled = true;

    document.body.appendChild(Renderer.domElement);
    Scene.position.set(0, -10, 0);

}

function setupCameraAndLight() {

    Camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1.0, 1000);
    Camera.position.set(-30, 10, 30);
    Camera.lookAt(Scene.position);
    orbitControls = new THREE.OrbitControls(Camera, Renderer.domElement);

    Scene.add(new THREE.AmbientLight(0x666666));

  	light = new THREE.DirectionalLight(0xeeeeee);
    light.position.set(20, 60, 10);
    light.castShadow = true;
    light.target = Scene;
    Scene.add(light);

    let hemiSphereLight = new THREE.HemisphereLight(0x7777cc, 0x00ff00, 0.6);//skycolor, groundcolor, intensity
    hemiSphereLight.position.set(0, 100, 0);
    Scene.add(hemiSphereLight);
}

function createGeometry() {

    Scene.add(new THREE.AxesHelper(100));
    
    // let plane = new THREE.Mesh(
    //     new THREE.PlaneGeometry(60, 40, 50, 50),
    //     new THREE.MeshStandardMaterial({color: 0xeeeeee})
    // );
    // plane.receiveShadow = true;
    // plane.rotation.x = -Math.PI * 0.5;
    // scene.add(plane);

    shaderMaterial = new THREE.ShaderMaterial(
        {
            uniforms: __shader.uniforms,
            vertexShader: __shader.vertexShader,
            fragmentShader: __shader.fragmentShader,
            transparent: true,
            // wireframe: true
        }
    );


    let plane = new THREE.Mesh(

        new THREE.PlaneGeometry(60, 40, 256, 256), shaderMaterial
        // new THREE.PlaneGeometry(60, 40), shaderMaterial
        // new THREE.MeshStandardMaterial({color: 0xeeeeee})
    );
    plane.receiveShadow = true;
    plane.rotation.x = -Math.PI * 0.5;
    Scene.add(plane);


    let box = new THREE.Mesh(
        new THREE.BoxBufferGeometry(10, 10, 10, 128, 128),
        shaderMaterial
    );
    box.position.set(10, 10, 10);
    box.rotation.set(Math.PI * 0.6, 0, Math.PI * 0.3);
    box.castShadow = true;
    Scene.add(box);

    // __shader.uniforms.textureA.value = new THREE.TextureLoader().load('assets/textures/general/stone-bump.jpg');
    // __shader.uniforms.textureB.value = new THREE.TextureLoader().load('assets/textures/general/stone.jpg');
	// __shader.uniforms.textureB.value = new THREE.TextureLoader().load('assets/textures/alpha/partial-transparency.png');
    // __shader.uniforms.textureA.value = new THREE.TextureLoader().load('assets/textures/general/lava.png');
  

    let ball = new THREE.Mesh( new THREE.SphereBufferGeometry( 3, 128, 128 ), shaderMaterial );
    ball.position.set(-10,10,-10);
    ball.castShadow = true;
    Scene.add( ball );
    
    console.log(`Using : ${__shader.name}`);

}

function setupDatGui() {

    controls = new function() {

        this.speed = 0.00;

    }

    let gui = new dat.GUI();
    gui.add(controls, 'speed', -0.05, 0.05, 0.01).onChange((e) => speed = e);

}

function render() {

    requestAnimationFrame(render);
    Scene.rotation.y += controls.speed;                           //rotates the scene
    // __shader.uniforms.time.value = clock.getElapsedTime();
    Renderer.render(Scene, Camera);

}

window.onload = () => {

    init();
    setupCameraAndLight();
    createGeometry();
    setupDatGui();
    render();

}
