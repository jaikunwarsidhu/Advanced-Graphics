//Jaikunwar Sidhu
//301055060
//05-Jaikunwar.js

let scene, SpotLight, Renderer, Camera, Controls, stats, control;

let spotLightColor = 0x404040;

let baseContainer, wheelContainer, WheelPlaceHolderCont, WheelCont, SpokeCont, SpokeContChild;
let Axle, GroundPlane, spoke, Rim;
let SpokesArray = [], RimArray = [], WheelArray = [], AxleArray = [];

let WheelNumber = 1, NumberOfSpokes = 10, OuterRadius = 10, InnerRadius = 8;
let xPosition = 0, yPosition = 0, zPosition = 0;
let AxleRadius = 1, SpokeLength = 9;

function init() {
    scene = new THREE.Scene();
    Renderer = new THREE.WebGLRenderer();
    Renderer.setSize(window.innerWidth, window.innerHeight);
    Renderer.setClearColor(0x228B22);
    Renderer.shadowMap.enabled = true;
    document.body.appendChild(Renderer.domElement);
}

function LightsCamera() {
    Camera = new THREE.PerspectiveCamera(
        90,                                         
        window.innerWidth / window.innerHeight,     
        1,                                        
        1000                                       
    );   
    Camera.position.set(0, 80, 120);  
    Camera.lookAt(scene.position);
    Controls = new THREE.OrbitControls(Camera, Renderer.domElement);
    Controls.update();  

    SpotLight = new THREE.SpotLight(spotLightColor, 3.0);
    SpotLight.position.set(0, 50, 0);
    SpotLight.receiveShadow = true;
    SpotLight.castShadow = true
    SpotLight.visible = true;
    scene.add(SpotLight);
}

function createGeometry() {
    let mat = new THREE.MeshLambertMaterial({ color: 0xDBFEF8});
    let geo = new THREE.PlaneGeometry(100, 100);
    GroundPlane = new THREE.Mesh(geo, mat);
    GroundPlane.rotation.x = -0.5 * Math.PI;
    GroundPlane.position.set(10,0,10);
    GroundPlane.receiveShadow = true;
    scene.add(GroundPlane);
    createContainers();
    createWheel(WheelNumber, NumberOfSpokes, OuterRadius, InnerRadius, xPosition, yPosition, zPosition);
}

function createContainers() {
   
    baseContainer = new THREE.Object3D();
    baseContainer.position.set(0, 30, 0);
    scene.add(baseContainer);    
    wheelContainer = new THREE.Object3D();
    wheelContainer.position.set(0, 0, 0);
    baseContainer.add(wheelContainer);
}

function createWheel(NumberOfWheels, numberOfSpokes, outerRadiusRim, innerRadiusRim, xPositionRim, yPositionRim, zPositionRim) {

    WheelPlaceHolderCont = new THREE.Object3D();   
    wheelContainer.add(WheelPlaceHolderCont);

    for (let w = 1; w <= NumberOfWheels; w++) {

        WheelCont = new THREE.Object3D();
        WheelCont.position.set(xPosition, yPosition, zPosition);
        WheelPlaceHolderCont.add(WheelCont);
        WheelArray.push(WheelCont);

        let geo = new THREE.CylinderGeometry(AxleRadius, AxleRadius, 4, 32);
        let mat = new THREE.MeshLambertMaterial({ color: 0xbb0000 });
        Axle = new THREE.Mesh(geo, mat);
        Axle.position.set(xPosition, yPosition, zPosition+1.5);
        Axle.rotation.x = Math.PI * 0.5;
        Axle.castShadow = true;
        Axle.receiveShadow = true;
        WheelCont.add(Axle);
        AxleArray.push(Axle);

        let absellipse = new THREE.Shape();
        absellipse.absellipse(0, 0, outerRadiusRim, outerRadiusRim);

        let absellipseHole = new THREE.Shape();
        absellipseHole.absellipse(0, 0, innerRadiusRim, innerRadiusRim)
        absellipse.holes.push(absellipseHole);
        let extrudeSettings = {
            steps: 2,
            depth: 1.5,
            bevelEnabled: false,
            bevelThickness: 5,
            bevelSize: 6,
            bevelOffset: 0,
            bevelSegments: 20
        };
        geo = new THREE.ExtrudeGeometry(absellipse, extrudeSettings);
        mat = new THREE.MeshLambertMaterial({ color: 0xff0000 });
        Rim = new THREE.Mesh(geo, mat);
        Rim.castShadow = true;
        Rim.receiveShadow = true;
        WheelCont.add(Rim);
        Rim.position.set(xPositionRim, yPositionRim, zPositionRim + 1);
        RimArray.push(Rim);

        let rotationMultiplier = 1;
        for (let y = 0; y < numberOfSpokes; y++) {
            createSpokes(Math.PI * rotationMultiplier, xPositionRim, yPositionRim, zPositionRim + 1);
            rotationMultiplier -= 2 / numberOfSpokes;
        }
    }
}

function createSpokes(rotationAngle, xPositionSpoke, yPositionSpoke, zPositionSpoke) {

    SpokeCont = new THREE.Object3D();
    SpokeCont.position.set(0, 0, 0);
    WheelCont.add(SpokeCont);
    SpokeContChild = new THREE.Object3D();
    SpokeContChild.position.set(0, 0, 0);
    SpokeCont.add(SpokeContChild);

    let geometry = new THREE.BoxGeometry(1, SpokeLength, 0.5, 32, 32, 32);
    geometry.translate(0.5, 5, 0);
    let material = new THREE.MeshNormalMaterial();
    spoke = new THREE.Mesh(geometry, material);
    spoke.position.set(xPositionSpoke, yPositionSpoke, zPositionSpoke + 0.5)
    spoke.rotation.z = rotationAngle;
    spoke.castShadow = true;
    spoke.receiveShadow = true;
    SpokeContChild.add(spoke);
    SpokesArray.push(spoke);
}
function setupDatgui() {
    control = new function () {
        this.name = "Jaikunwar Sidhu";     
        this.Size = 1;        
        this.NumberOfSpokes = NumberOfSpokes;
        this.RimThickness = 1;
        this.Xposition = xPosition;
        this.Yposition = yPosition;
        this.Zposition = zPosition;
        this.Add_Wheel = function()
        {createWheel(1, NumberOfSpokes, OuterRadius, InnerRadius, xPosition, yPosition, zPosition)} ;
    }
    let gui = new dat.GUI();
    gui.add(control, "name");
    gui.add(control, "Size", 0.1, 2, 0.1)
        .onChange((e) => {
            wheelContainer.scale.x = e;
            wheelContainer.scale.y = e;
            wheelContainer.scale.z = e;
        });;
    gui.add(control, "NumberOfSpokes", 1, 20, 1)
        .onChange((e) => {
            NumberOfSpokes = e;
            wheelContainer.remove(WheelPlaceHolderCont);
            SpokesArray = [];
            RimArray = [];
            createWheel(WheelNumber, NumberOfSpokes, OuterRadius, InnerRadius, xPosition, yPosition, zPosition);
        });
    gui.add(control, "RimThickness").onChange((e) => {
            let thickness = e;
            wheelContainer.remove(WheelPlaceHolderCont);
            SpokesArray = [];
            RimArray = [];
            createWheel(WheelNumber, NumberOfSpokes, OuterRadius, InnerRadius-thickness+1, xPosition, yPosition, zPosition);
    });
    gui.add(control, "Xposition").onChange((e) => {
        xPosition = e;
    });
    gui.add(control, "Yposition").onChange((e) => {
        yPosition = e;
    });
    gui.add(control, "Zposition").onChange((e) => {
        zPosition = e;
    });
    gui.add(control, "Add_Wheel", 1, 20, 1);
}

function render() {
    requestAnimationFrame(render);
    Renderer.render(scene, Camera);
}

window.onload = function () {
    this.init();
    this.LightsCamera();
    this.createGeometry();
    this.setupDatgui();
    this.render();
}