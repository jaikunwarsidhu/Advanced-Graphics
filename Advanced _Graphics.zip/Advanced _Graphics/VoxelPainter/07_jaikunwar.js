//Jaikunwar Sidhu
//301055060

let Scene, Camera,AxesHelper;
let  Sizegrd = 10, dimensionsgrd = 10;
let GridLoc_X = (dimensionsgrd/2)-0.5;
let GridLoc_z = (dimensionsgrd/2)-0.5;
let planeArr = [];
let textureCube = new THREE.TextureLoader().load( "../assets/textures/square.png" );

function init() {

    Scene = new THREE.Scene();
    Renderer = new THREE.WebGLRenderer();
    Renderer.setSize(window.innerWidth, window.innerHeight);
    Renderer.setClearColor(0x808080);
    Renderer.shadowMap.enabled = true;
    document.body.appendChild(Renderer.domElement);
    Stats = new Stats();
    Stats.showPanel(0);
    document.body.appendChild(Stats.dom);
}

function createCameraAndLights() {
    Camera = new THREE.PerspectiveCamera(20, window.innerWidth/window.innerHeight, 0.1, 100);
    Camera.position.set(20, 50, 55);
    Camera.lookAt(Scene.position);
    Controls = new THREE.OrbitControls(Camera, Renderer.domElement);
    Controls.update();
    AxesHelper = new THREE.AxesHelper(20);
    Scene.add(AxesHelper);
    AmbientLight = new THREE.AmbientLight(0xFFFFFF, 1);
    AmbientLight.position.set(0, 50, 0);
    AmbientLight.visible = true;
    Scene.add(AmbientLight);
}

function createGeometry() {
    Grid = new THREE.GridHelper(10,10, 0xFFFFFF,0xFFFFFF);
    Scene.add(Grid);
    for(let a = 0; a<dimensionsgrd; a++){
        for(let b = 0; b<dimensionsgrd; b++){
            let mat = new THREE.MeshLambertMaterial({ color: 0xC0C0C0, visible: false });
            let geo = new THREE.PlaneGeometry(1, 1);
            Plane = new THREE.Mesh(geo, mat);
            Plane.rotation.x = -0.5 * Math.PI;
            Plane.position.x = GridLoc_X-a;
            Plane.position.z = GridLoc_z-b;
            Scene.add(Plane);
            planeArr.push(Plane);
        }
    }
}
function mouseDownHandler(event){
    let raycaster = new THREE.Raycaster();
    let mouse = new THREE.Vector3();
    mouse.x = (event.clientX/window.innerWidth)*2-1;
    mouse.y = -(event.clientY/window.innerHeight)*2+1;
    raycaster.setFromCamera(mouse, Camera);
    let intersections = raycaster.intersectObjects(planeArr);
    if(intersections[0]){
        createTheCube(intersections[0]);
    }
}

function createTheCube(clickedElement){
    let elementX = clickedElement.object.position.x;
    let elementZ = clickedElement.object.position.z;
    let elementY = clickedElement.object.position.y+0.5;
    let geo = new THREE.BoxGeometry(1,1,1);
    let mat = new THREE.MeshLambertMaterial( {map: textureCube});
    let boxMesh = new THREE.Mesh(geo,mat);
    boxMesh.position.x = elementX;
    boxMesh.position.y = elementY;
    boxMesh.position.z = elementZ;
    Scene.add(boxMesh);
    clickedElement.object.position.y += 1;
}

function render() {
    Stats.begin();
    Stats.end();
    requestAnimationFrame(render);
    Renderer.render(Scene, Camera);
}
window.onload = function () {
    this.init();
    this.createCameraAndLights();
    this.createGeometry();
    window.addEventListener('click', this.mouseDownHandler,false);
    this.render();
}