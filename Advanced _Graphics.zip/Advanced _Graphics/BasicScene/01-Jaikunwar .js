
let Renderer, Scne, Camera, OrbitControl;
let SpotLight;
const color = 0xF08080;

function init() {
    Scne = new THREE.Scene(); //Scene 
    Renderer = new THREE.WebGLRenderer({ antialias: true }); //newRenderer   
    Renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    Renderer.outputEncoding = THREE.sRGBEncoding;
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setClearColor(0x97B9BD); //Background or page color
    Renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(Renderer.domElement);
    Renderer.shadowMap.enabled = true;

}
function createGeometry() {
    Scne.add(new THREE.AxesHelper(20));


    let planeGeo = new THREE.PlaneBufferGeometry(50, 50);
    let planeMat = new THREE.MeshLambertMaterial({ color: 0x0495ED });
    let planeMesh = new THREE.Mesh(planeGeo, planeMat);
   
    planeMesh.rotation.x = -0.5 * Math.PI;
    Scne.add(planeMesh);

    let cubeGeo = new THREE.BoxGeometry(5, 10,  5);
    let cubeMat = new THREE.MeshStandardMaterial( {color: 0x454545} );
    let cube = new THREE.Mesh( cubeGeo, cubeMat );
    cube.position.set(0,10,00);
    Scne.add( cube );

    let geometry = new THREE.SphereGeometry( 5, 40, 32 );
        let material = new THREE.MeshLambertMaterial( {color: color} );
        let sphere = new THREE.Mesh( geometry, material );
        sphere.position.set(10,10,0);
        Scne.add(sphere);
         geometry = new THREE.CylinderGeometry( 5, 5, 10, 32 );
         material = new THREE.MeshBasicMaterial( {color: color} );
        let cylinder = new THREE.Mesh( geometry, material );
        cylinder.position.set(-10, 10, 0);
        Scne.add(cylinder);
}


function setupCameraAndLight() {
    Camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100);
    Camera.position.set(50, 50, 50);
    Camera.lookAt(Scne.position);
   

    OrbitControl = new THREE.OrbitControls(Camera, Renderer.domElement);
    OrbitControl.update();

    AmbientLight = new THREE.AmbientLight(color, 1);
    AmbientLight.position.set(15, 50, -15)
    Scne.add(AmbientLight);

    SpotLight = new THREE.SpotLight(color, 1);
    SpotLight.castShadow = true;
    SpotLight.position.set(-15, 70, 15);
    Scne.add(SpotLight);
}
function render() {
    requestAnimationFrame(render);
    Renderer.render(Scne, Camera);
}

window.onload = (event) => {
    init();
    setupCameraAndLight();
    createGeometry();
    render();
}