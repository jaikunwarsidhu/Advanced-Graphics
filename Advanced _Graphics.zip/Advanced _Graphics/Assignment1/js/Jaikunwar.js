


//declare recurrent variables
let scene;
let renderer;
let camera;
let controls;
let stats;
let directionalLight;
let pointLightColor = 0x40404;



let Radius_Sun = 696.340;;
let sunWidthSeg = 20;
let sundHeightSeg = 32;
let sunColor = 0xFF7F00;
let sunXPosition = 0;
let sunYPosition = 0;
let sunZPosition = 0;
let sunXRotation = 0;
let sunYRotation = 0;
let sunZRotation = 0;
let sunEmissive = 0xFAFD0F;
let RotSpeed = 0.001;


let axes,
    control;
//Geometry
let sun, mercury, venus, earth, earthMoon, mars, jupiter,
    jupiterM1, jupiterM2, jupiterM3, jupiterM4, jupiterM5,
    saturnMoon1, saturnM2, saturnM3, 
    saturn, satRing, uranus, neptune, pluto,
    sunCon,mercuryCon, venusCon, earthCon, marsCon, jupiterCon, 
    saturnCon, uranusCon, neptuneCon, plutoCon;
// Array for planets
let planets = [];
let OrbitCircle = [];

//define javascript functions

//init
function init() {
        
        
        scene = new THREE.Scene();
        renderer = new THREE.WebGLRenderer();
        renderer.setSize(window.innerWidth, window.innerHeight);       
        document.body.appendChild(renderer.domElement);
        renderer.setClearColor(0x000000);
        renderer.shadowMap.enabled = true;

        //Stats<<
        stats = new Stats();
        stats.showPanel(0);
        document.body.appendChild(stats.dom);
}

//createCameraAndLights
function createCameraAndLights() {
        //create the camera
        camera = new THREE.PerspectiveCamera(
        90,                                        
        window.innerWidth / window.innerHeight,    
        0.1,                                       
        1000000                                         
        );
        //set its position
        camera.position.set(-3000, 5000, 8000);
        //point the camera
        camera.lookAt(scene.position);
        controls = new THREE.OrbitControls( camera, renderer.domElement );
        controls.update();
        //Point light
        pointLight = new THREE.PointLight(pointLightColor, 200);
        pointLight.position.set( 0, 2000, 10 );
        pointLight.castShadow = true;
        scene.add(pointLight);

}

//createGeometry{}
function createGeometry() {

    
    //Sun
    sun = createPlanet(Radius_Sun,sunWidthSeg,sundHeightSeg,sunColor, sunXPosition,sunYPosition,sunZPosition,sunEmissive);
    sunCon = Container();
    scene.add(sunCon);
    sunCon.add(sun);
    //Mercury
    mercury = createPlanet(4.8*2,20,32,0xC0C0C0, (sunXPosition+57.9*20),0,0);
    mercuryCon = Container();
    scene.add(mercuryCon);
    mercuryCon.add(mercury);
    planets.push(mercury);
    //Venus
    venus = createPlanet(12.1*2,20,32,0xebe939, (sunXPosition+108.1*20),0,0);
    venusCon = Container();
    scene.add(venusCon);
    venusCon.add(venus);
    planets.push(venus);
    //Earth
    earth = createPlanet(12.7*2,20,32,0x0000ff, (sunXPosition+149.6*20),0,0);
    earthCon = Container();
    scene.add(earthCon);
    earthCon.add(earth);
    planets.push(earth);
    //Earth moon
    earthMoon = createPlanet(4*2,20,32,0xC0C0C0, (earth.scale.x+10)*5,0,0);
    earth.add(earthMoon);
    
    //Mars
    mars = createPlanet(6.7*2,20,32,0xE27B58, (sunXPosition+227.9*20),0,0);
    marsCon = Container();
    scene.add(marsCon);
    marsCon.add(mars);
    planets.push(mars);
    //Jupiter
    jupiter = createPlanet(142.9*3,20,32,0xFF7F00, (sunXPosition+778.3*20),0,0);
    jupiterCon = Container();
    scene.add(jupiterCon);
    jupiterCon.add(jupiter);
    planets.push(jupiter);
    //Jupiter's moons
    jupiterM1 = createPlanet(8*2,20,32,0xC0C0C0, (jupiter.scale.x-50)*10,-200,-245);
    jupiter.add(jupiterM1);
    jupiterM2 = createPlanet(8*2,20,32,0xC0C0C0, (jupiter.scale.x-50)*10,-100,-50);
    jupiter.add(jupiterM2);
    jupiterM3 = createPlanet(8*2,20,32,0xC0C0C0, (jupiter.scale.x+50)*10,0,0);
    jupiter.add(jupiterM3);
    jupiterM4 = createPlanet(8*2,20,32,0xC0C0C0, (jupiter.scale.x+50)*10,200,50);
    jupiter.add(jupiterM4);
    jupiterM5 = createPlanet(8*2,20,32,0xC0C0C0, (jupiter.scale.x+50)*10,400,185);
    jupiter.add(jupiterM5);
    //Saturn
    saturn = createPlanet(120.5*3,20,32,0xc2bd60, (sunXPosition+1427*20),0,0);
    satRing = createRing(600,750,32,0xc2bd60);
    
    saturnCon = Container();
    scene.add(saturnCon);
    saturnCon.add(saturn);
    saturn.add(satRing);
    planets.push(saturn);
    //Saturn's moons
    saturnMoon1 = createPlanet(4*2,20,32,0xC0C0C0, (saturn.scale.x+10)*5,0,0);
    saturn.add(saturnMoon1);
    saturnM2 = createPlanet(4*2,20,32,0xC0C0C0, (saturn.scale.x+10)*5,0,0);
    saturn.add(saturnM2);
    saturnM3 = createPlanet(4*2,20,32,0xC0C0C0, (saturn.scale.x+10)*5,0,0);
    saturn.add(saturnM3);
    //Uranus
    uranus = createPlanet(51.1*2,20,32,0x000080, (sunXPosition+2870*20),0,0);
    uranusCon = Container();
    scene.add(uranusCon);
    uranusCon.add(uranus);
    planets.push(uranus);
    //Neptune
    neptune = createPlanet(49.5*2,20,32,0x000090, (sunXPosition+4496.9*20),0,0);
    neptuneCon = Container();
    scene.add(neptuneCon);
    neptuneCon.add(neptune);
    planets.push(neptune);
    //Pluto
    pluto = createPlanet(2.3*5,20,32,0xc89357, (sunXPosition+5906.4*20),0,0);
    plutoCon = Container();
    scene.add(plutoCon);
    plutoCon.add(pluto);
    planets.push(pluto);

}
function createPlanet(radius,widthSegments, heightSegments,color,xPosition, yPosition, zPosition,emissive){

    
        //create the planet
        let mat = new THREE.MeshLambertMaterial({color: color, emissive: emissive});
        let geo = new THREE.SphereBufferGeometry(radius,widthSegments,heightSegments);
        let planet = new THREE.Mesh(geo, mat);
        planet.position.set(xPosition,yPosition,zPosition);
        
        let segments = 64;
        let lineMat = new THREE.LineBasicMaterial( { color: 0xffffff } );
        let lineGeo = new THREE.CircleGeometry( xPosition, segments );
        lineGeo.vertices.shift();

        let Orbit = new THREE.LineLoop( lineGeo, lineMat );
        Orbit.rotation.x = Math.PI * 0.5; 
        scene.add( Orbit );
        OrbitCircle.push(Orbit);
        

        return planet;
        
}

function Container(){
    let container = new THREE.Object3D();
    container.position.set(0, 0, 0);

    return container;
}

function createRing(ringInnerRadius, ringOuterRadius, ringThetaSegments, ringColor){
    //saturn's ring
    let ringGeo = new THREE.RingGeometry(ringInnerRadius, ringOuterRadius, ringThetaSegments);
    let ringMat = new THREE.MeshBasicMaterial({color: ringColor});
    let ringMesh = new THREE.Mesh(ringGeo, ringMat);
   
    ringMesh.material.side = THREE.DoubleSide;    
    ringMesh.rotation.x = Math.PI*0.5;

    return ringMesh;
}

function setupDatgui() {
   
        control = new function () {
            this.Rotation = true;
            this.Planet_Scales = 3;
            this.lineBoolean = true;
            this.Rotation_Speed = 0.01;
        
        }
        let gui = new dat.GUI();
        gui.add(control, "Rotation");
        gui.add(control, "Planet_Scales", 1, 10, 0.2)
                .onChange((e) => {scalePlanets(e);});
        gui.add(control, "lineBoolean")
                .onChange((e) => {showOrbit(e);});
        gui.add(control, "Rotation_Speed",0.01,0.10,0.01)
                .onChange((e) => {RotSpeed = e;})
    }

function scalePlanets(planetRadius){
    for(let i = 0; i<planets.length;i++){
        planets[i].scale.x = planetRadius;
        planets[i].scale.y = planetRadius;
        planets[i].scale.z = planetRadius;
    }
}
//showing orbit 
function showOrbit(visibleBool){
    for(let i = 0; i<OrbitCircle.length; i++){
        OrbitCircle[i].visible = visibleBool;
        console.log("here we are")
    }
}

//rotation function for planets
function rotatePlanets(){
    sun.rotation.y += RotSpeed;
    mercury.rotation.y += RotSpeed*0.08;
    venus.rotation.y += RotSpeed*0.01;
    earth.rotation.y += RotSpeed;
    mars.rotation.y += RotSpeed;
    jupiter.rotation.y += RotSpeed*2.3;
    saturn.rotation.y += RotSpeed*2.2;
    uranus.rotation.y += RotSpeed*1.5;
    neptune.rotation.y += RotSpeed*1.6;
    pluto.rotation.y += RotSpeed*0.16;
    sunCon.rotation.y += RotSpeed;
    mercuryCon.rotation.y += RotSpeed*4;
    venusCon.rotation.y += RotSpeed*3;
    earthCon.rotation.y += RotSpeed;
    marsCon.rotation.y += RotSpeed*0.5;
    jupiterCon.rotation.y += RotSpeed*0.4;
    saturnCon.rotation.y += RotSpeed*0.3;
    uranusCon.rotation.y += RotSpeed*0.2;
    neptuneCon.rotation.y += RotSpeed*0.1;
    plutoCon.rotation.y += RotSpeed*0.08;
}

//render
function render() {
        stats.begin();
        stats.end();
        if(control.Rotation == true){
            rotatePlanets();
        }
        if(control.lineBoolean == false){

        }
        
        requestAnimationFrame(render);
        renderer.render(scene, camera);
}

//javascript function to drive your scene
window.onload = function () {
        this.init();
        this.createCameraAndLights();
        this.createGeometry();
        this.setupDatgui();
        this.render();
}