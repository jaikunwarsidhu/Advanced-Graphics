
let Renderer, Scne, Camera, OrbitControl;
let hemisphereLight;
const color = 0xF08080;

function init() {
    Scne = new THREE.Scene(); //Scene 
    Renderer = new THREE.WebGLRenderer({ antialias: true }); //newRenderer   
    Renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    Renderer.outputEncoding = THREE.sRGBEncoding;
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setClearColor(0x97B9BD); //Background or page color
    Renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(Renderer.domElement);
    Renderer.shadowMap.enabled = true;

}
function createGeometry() {
    Scne.add(new THREE.AxesHelper(20));


    let planeGeo = new THREE.PlaneBufferGeometry(50, 50);
    let planeMat = new THREE.MeshLambertMaterial({ color: 0x0495ED });
    let planeMesh = new THREE.Mesh(planeGeo, planeMat);
    planeMesh.receiveShadow = true;
    planeMesh.rotation.x = -0.5 * Math.PI;
    Scne.add(planeMesh);
}


function setupCameraAndLight() {
    Camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100);
    Camera.position.set(0, 10, 50);
    Camera.lookAt(Scne.position);
   

    orbitControls = new THREE.OrbitControls(Camera, Renderer.domElement)
    
    DirectionalLight = new THREE.DirectionalLight(color, 1);
    DirectionalLight.position.set(15, 50, -15)
    DirectionalLight.castShadow = true;
    Scne.add(DirectionalLight);

    hemisphereLight = new THREE.HemisphereLight( 0xffffbb, 0x080820, 1 );
    hemisphereLight.position.set(-15, 70, 15);
    Scne.add(hemisphereLight);
    
}
function createCubeTexture(){
    let cubeLoader = new THREE.CubeTextureLoader().setPath( 'assets/textures/cubemap/park2/' );
    let urls = [
        'posx.jpg', //left
        'negx.jpg', //right
        'posy.jpg', //top
        'negy.jpg', //bottom
        'posz.jpg', //back
        'negz.jpg'  //front
      ];
    return cubeLoader.load(urls);      

}


function render() {
    requestAnimationFrame(render);
    Renderer.render(Scne, Camera);
    orbitControls.update();
}

window.onload = (event) => {
    init();
    setupCameraAndLight();
    createGeometry();
    render();
}