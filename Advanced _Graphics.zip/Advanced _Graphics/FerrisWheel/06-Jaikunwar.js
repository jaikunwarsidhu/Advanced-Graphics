let Scne,Renderer,camera,controls,stats,Light,LightColor=0xDBE7D7,control;

let RawCont, wheelContainer, WheelContainer,ferrisWheelContainer, spokeContainer,spokeContainerChild;
let axle,plane,spoke,rimMesh1,SeatSpoke, Seat;
let spokeArr = [], SeatArr = [], rimMeshArr = [], ferrishWheelArr = [], axleArray = [];

let wheelAmount = 3,numberOfSpokes = 14,outerRadiusRim = 10,innerRadiusRim = 9,xPosition = 0,yPosition = 0, zPosition = 0,axleRadius = 2,spokeLength = 13.5,wheelRadius = 20;


function init() {

    Scne = new THREE.Scene();
    Renderer = new THREE.WebGLRenderer();
    Renderer.setSize(window.innerWidth, window.innerHeight);
    Renderer.setClearColor(0x00ff00);
    Renderer.shadowMap.enabled = true;
    document.body.appendChild(Renderer.domElement);
}
function createCameraAndLights() {
    camera = new THREE.PerspectiveCamera(
        60,                                         
        window.innerWidth / window.innerHeight,     
        0.1,                                        
        1000                                        
    );
    camera.position.set(0, 40, -80);
    camera.lookAt(Scne.position);
    controls = new THREE.OrbitControls(camera, Renderer.domElement);
    controls.update();
    Light = new THREE.SpotLight(LightColor, 20);
    Light.position.set(0, 50, 0);
    Light.receiveShadow = true;
    Light.castShadow = true
    Light.visible = true;    
    Scne.add(Light);
    
}

function createGeometry() {
    //plane
    let mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    let geo = new THREE.PlaneGeometry(100, 100);
    plane = new THREE.Mesh(geo, mat);
    plane.rotation.x = -0.5 * Math.PI;
    plane.receiveShadow = true;
    Scne.add(plane);
    createContainers();
    createWheel(wheelAmount,numberOfSpokes,outerRadiusRim,innerRadiusRim,xPosition,yPosition,zPosition);
    
   
}

function createContainers(){
    RawCont = new THREE.Object3D();
    RawCont.position.set(0, 25, 0);
    RawCont.rotation.x = Math.PI;
    RawCont.rotation.y =Math.PI;
    Scne.add(RawCont);
    wheelContainer = new THREE.Object3D();
    wheelContainer.position.set(0, 0, 0);
    RawCont.add(wheelContainer);

    

}

function createWheel(numberOfFerrisWheels,numberOfSpokes,outerRadiusRim,innerRadiusRim,xPositionRim,yPositionRim,zPositionRim){
    WheelContainer = new THREE.Object3D();
    WheelContainer.position.set(0, 0, 0);
    wheelContainer.add(WheelContainer);
        ferrisWheelContainer = new THREE.Object3D();
        ferrisWheelContainer.position.set(0, 0,0);
        WheelContainer.add(ferrisWheelContainer);
        ferrishWheelArr.push(ferrisWheelContainer);

        let geo = new THREE.CylinderGeometry( axleRadius, axleRadius, 8, 32 );
        let mat = new THREE.MeshLambertMaterial({ color: 0xDAFC00 });
        axle = new THREE.Mesh(geo, mat);
        axle.position.set(0,0,4);
        axle.rotation.x=Math.PI*0.5;
        axle.castShadow = true;
        axle.receiveShadow = true;
        ferrisWheelContainer.add(axle);
        axleArray.push(axle);

        let absellipse1 = new THREE.Shape();
        absellipse1.absellipse(0, 0, outerRadiusRim, outerRadiusRim);
        let absellipseHole1 = new THREE.Shape();
        absellipseHole1.absellipse(0, 0, innerRadiusRim, innerRadiusRim)
        absellipse1.holes.push(absellipseHole1);
        let extrudeSettings = {
            steps: 2,
            depth: 1,
            bevelEnabled: false,
            bevelThickness: 1,
            bevelSize: 1,
            bevelOffset: 0,
            bevelSegments: 1
        };
        geo = new THREE.ExtrudeGeometry(absellipse1, extrudeSettings);
        mat = new THREE.MeshLambertMaterial({ color: 0xDAFC00});
        rimMesh1 = new THREE.Mesh(geo, mat);
        rimMesh1.castShadow = true;
        rimMesh1.receiveShadow = true;
        ferrisWheelContainer.add(rimMesh1);
        rimMesh1.position.set(xPositionRim,yPositionRim,zPositionRim+1);
        rimMeshArr.push(rimMesh1);
        rimMesh2 = new THREE.Mesh(geo, mat);
        rimMesh2.castShadow = true;
        rimMesh2.receiveShadow = true;
        ferrisWheelContainer.add(rimMesh2);
        rimMesh2.position.set(xPositionRim,yPositionRim,zPositionRim+6);
        rimMeshArr.push(rimMesh2);

        let rotationMultiplier = 1;
        for(let y = 0; y<numberOfSpokes; y++){
            createSpokesAndseats(Math.PI*rotationMultiplier,xPositionRim,yPositionRim,zPositionRim+1);
            rotationMultiplier -= 2/numberOfSpokes;   
        }   
}
function createSpokesAndseats(rotationAngle,xPositionSpoke,yPositionSpoke,zPositionSpoke){
    
  spokeContainer = new THREE.Object3D();
  spokeContainer.position.set(0, 0, 0);
  ferrisWheelContainer.add(spokeContainer);

  spokeContainerChild = new THREE.Object3D();
  spokeContainerChild.position.set(0,0,0);
  
  spokeContainer.add(spokeContainerChild);

    let geometry = new THREE.BoxGeometry( 1, spokeLength, 0.5, 32,32,32 );
    geometry.translate(0.5,5,0);
    let material = new THREE.MeshNormalMaterial({color: 0x41DF11});
    spoke = new THREE.Mesh( geometry, material );
    spoke.position.set(xPositionSpoke,yPositionSpoke,zPositionSpoke+0.5)
    spoke.rotation.z = rotationAngle;
    spoke.castShadow = true;
    spoke.receiveShadow = true;
    spokeContainerChild.add(spoke);
    spokeArr.push(spoke);
    spoke2 = new THREE.Mesh( geometry, material );
    spoke2.position.set(xPositionSpoke,yPositionSpoke,zPositionSpoke+5.5)
    spoke2.rotation.z = rotationAngle;
    spoke2.castShadow = true;
    spoke2.receiveShadow = true;
    spokeContainerChild.add(spoke2);
    spokeArr.push(spoke2);
    
    geometry = new THREE.BoxGeometry( 0.5, 5, 0.5, 32,32,32 );
    material = new THREE.MeshNormalMaterial();
    seatSpoke = new THREE.Mesh( geometry, material );
    seatSpoke.position.set(0.5, yPositionSpoke+11.5,2.5)
    seatSpoke.rotation.x = Math.PI*0.5;
    seatSpoke.rotation.y = -rotationAngle;
    seatSpoke.castShadow = true;
    seatSpoke.receiveShadow = true;
    spoke.add(seatSpoke);
    
    geometry = new THREE.BoxGeometry( 0.5, 3, 0.5, 32,32,32 );
    material = new THREE.MeshNormalMaterial();
    SeatSpoke = new THREE.Mesh( geometry, material );
    SeatSpoke.position.set(0, 0,-1.5)
    SeatSpoke.rotation.x = Math.PI*0.5;
    SeatSpoke.castShadow = true;
    SeatSpoke.receiveShadow = true;
    seatSpoke.add(SeatSpoke);

    geometry = new THREE.SphereGeometry(1,32,32,0,Math.PI*2,0,2)
    material = new THREE.MeshLambertMaterial({color: 0xAFB5D9});
    Seat = new THREE.Mesh(geometry, material);
    Seat.position.set(0,-1,0);
    Seat.rotation.x = Math.PI;
    Seat.castShadow = true;
    Seat.receiveShadow = true;
    SeatSpoke.add(Seat);
    SeatArr.push(seatSpoke);
   
}
function setupDatgui() {
    control = new function () {
        this.OuterRadiusRim = outerRadiusRim;
        this.InnerRadiusRim = innerRadiusRim;
        this.RimWidth = 1;
        this.AxleRadius = 1;
        this.SpokeLength = 1;
        this.NumberOfSpokes = numberOfSpokes;
        this.ToggleSceneRotation = false;
        this.ToggleWheelRotation = false;
    }
    let gui = new dat.GUI();

    gui.add(control, "OuterRadiusRim",5,15,1)
            .onChange((e) => {
                outerRadiusRim = e;
            });
    gui.add(control, "InnerRadiusRim", 1,15,1)
            .onChange((e) => {
                innerRadiusRim = e;
            });
    gui.add(control, "RimWidth",0.1,2,0.1)
            .onChange((e) => {
                wheelContainer.scale.x = e;
                wheelContainer.scale.y = e;
                wheelContainer.scale.z = e;
            });;
    gui.add(control, "AxleRadius",0.1,2,0.1)
            .onChange((e) => {
                axleArray.forEach(element => {
                    element.scale.x = e;
                    element.scale.y = e;
                    element.scale.z = e;
                });
            });
    gui.add(control, "SpokeLength",0.5,2,0.1)
            .onChange((e) => {
                spokeArr.forEach(element => {
                    element.scale.y = e;
                });;
            });
    gui.add(control, "NumberOfSpokes",1,20,1)
            .onChange((e) => {
                numberOfSpokes = e;
                wheelContainer.remove(WheelContainer);
                SeatArr = [];
                spokeArr = [];
                rimMeshArr = [];
                wheelAngle = 0;
                createWheel(wheelAmount,numberOfSpokes,outerRadiusRim,innerRadiusRim,xPosition,yPosition,zPosition);
            });
    gui.add(control, "ToggleSceneRotation");
    gui.add(control, "ToggleWheelRotation");
}

function render() {
    if (control.ToggleSceneRotation) {
        Scne.rotation.y = sceneAngle += 0.02;
    }
    if (control.ToggleWheelRotation) {
        ferrishWheelArr.forEach(element => {
            element.rotation.z += 0.02;  
        });
        SeatArr.forEach(element => {
            element.rotation.y -=0.02;
        });
    }
    requestAnimationFrame(render);
    Renderer.render(Scne, camera);
}
window.onload = function () {
    this.init();
    this.createCameraAndLights();
    this.createGeometry();
    this.setupDatgui();
    this.render();
}