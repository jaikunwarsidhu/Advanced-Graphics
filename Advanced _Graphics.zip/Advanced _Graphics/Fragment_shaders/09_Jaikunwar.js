//Jaikunwar Sidhu
//301055060

//Shaders
let Shaders = {}
Shaders.BasicShader9B0 = {

	name: 'BasicShader9B0', //for debugging

	uniforms: {

		'time': { type: 'f', value: 0.0 },
        'textureA' : {value: null},
        'textureC' : {value: null}
	},
	
	vertexShader: 
	
	`uniform float time;

	varying vec2  vUv;

	void main() {
		vec3 pos = position;
       	vUv = uv;
		gl_Position = projectionMatrix * modelViewMatrix * vec4( pos, 1.0 );

	}`,


	fragmentShader:

	`uniform float time;
    uniform sampler2D textureA;
    uniform sampler2D textureC;
    
    
    varying vec2 vUv;

	 //vec3 color = vec3(1.0, 1.0, 0.0);         //local variable red

	void main() {
        
        vec4 colorA = texture2D(textureA, vUv);
        vec4 colorC = texture2D(textureC, vUv);
		gl_FragColor =  mix (colorA, colorC, abs(sin (time)));

	}`
};

Shaders.BasicShader9B1 = {

	name: 'BasicShader9B1', //for debugging

	uniforms: {

		'time': { type: 'f', value: 0.0 },
        
        'textureB' : {value: null}
	},
	
	vertexShader: 
	
	`uniform float time;

	varying vec2  vUv;

	void main() {
		vec3 pos = position;
       	vUv = uv;
		gl_Position = projectionMatrix * modelViewMatrix * vec4( pos, 1.0 );

	}`,
	fragmentShader:

	`uniform sampler2D textureB;
    
    
    varying vec2 vUv;

	 //vec3 color = vec3(1.0, 1.0, 0.0);         //local variable red

	void main() {
        
        vec4 colorB = texture2D(textureB, vUv);
   
		gl_FragColor = colorB;

	}`
};



//MainFile
const clock = new THREE.Clock();
const __shader = Shaders.BasicShader9B0;
const __shaderA = Shaders.BasicShader9B1;

function init() {
    Renderer = new THREE.WebGLRenderer({ antialias: true });
    Scene = new THREE.Scene();
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setSize(window.innerWidth, window.innerHeight);
    Renderer.setClearColor(0x004400);
    Renderer.shadowMap.enabled = true;

    document.body.appendChild(Renderer.domElement);
    Scene.position.set(0, -10, 0);
    Scene.rotation.set(0,160,0);

}

function setupCameraAndLight() {

    Camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1.0, 1000);
    Camera.position.set(-20, 0, 70);
    Camera.lookAt(Scene.position);
    orbitControls = new THREE.OrbitControls(Camera, Renderer.domElement);

    Scene.add(new THREE.AmbientLight(0x666666));

  	light = new THREE.DirectionalLight(0xeeeeee);
    light.position.set(20, 60, 10);
    light.castShadow = true;
    light.target = Scene;
    Scene.add(light);

    let hemiSphereLight = new THREE.HemisphereLight(0x7777cc, 0x00ff00, 0.6);
    hemiSphereLight.position.set(0, 100, 0);
    Scene.add(hemiSphereLight);
}

function createGeometry() {

    Scene.add(new THREE.AxesHelper(100));

    shaderMaterialA = new THREE.ShaderMaterial(
        {
            uniforms: __shader.uniforms,
            vertexShader: __shader.vertexShader,
            fragmentShader: __shader.fragmentShader,
        }
    );
    shaderMaterialB = new THREE.ShaderMaterial(
        {
            uniforms: __shaderA.uniforms,
            vertexShader: __shaderA.vertexShader,
            fragmentShader: __shaderA.fragmentShader,
        }
    );

    let mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    let plane = new THREE.Mesh(

        new THREE.PlaneGeometry(60, 40, 256, 256),  mat
    );
    plane.receiveShadow = true;
    plane.rotation.x = -Math.PI * 0.5;
    Scene.add(plane);


    let box = new THREE.Mesh(
        new THREE.BoxBufferGeometry(10, 10, 10, 128, 128),
        shaderMaterialA
    );
    box.position.set(10, 10, 10);
    box.castShadow = true;
    Scene.add(box);


    let knot = new THREE.Mesh(
         new THREE.TorusKnotGeometry( 2, 0.8, 100, 10  ), shaderMaterialB );
         knot.position.set(-10,10,-10);
         knot.castShadow = true;
    Scene.add( knot );
            
    __shader.uniforms.textureA.value = new THREE.TextureLoader().load('../assets/textures/general/txtr.jfif')
    __shaderA.uniforms.textureB.value = new THREE.TextureLoader().load('../assets/textures/general/tettr.jpg')
    __shader.uniforms.textureC.value = new THREE.TextureLoader().load('../assets/textures/general/textr.png')
   
    console.log(`Using : ${__shader.name}`);

}

function setupDatGui() {

    controls = new function() {

        this.speed = 0.00;

    }

    let gui = new dat.GUI();
    gui.add(controls, 'speed', -0.05, 0.05, 0.01).onChange((e) => speed = e);

}

function render() {

    requestAnimationFrame(render);
    Scene.rotation.y += controls.speed;
    __shader.uniforms.time.value = clock.getElapsedTime();
    Renderer.render(Scene, Camera);

}

window.onload = () => {

    init();
    setupCameraAndLight();
    createGeometry();
    setupDatGui();
    render();

}
