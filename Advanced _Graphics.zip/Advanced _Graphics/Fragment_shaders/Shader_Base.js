let Shaders = {}
Shaders.BasicShader9B0 = {

	name: 'BasicShader9B0', //for debugging

	uniforms: {

		'time': { type: 'f', value: 0.0 },
        'textureA' : {value: null},
        'textureC' : {value: null}
	},
	
	vertexShader: 
	
	`uniform float time;

	varying vec2  vUv;

	void main() {
		vec3 pos = position;
       	vUv = uv;
		gl_Position = projectionMatrix * modelViewMatrix * vec4( pos, 1.0 );

	}`,


	fragmentShader:

	`uniform float time;
    uniform sampler2D textureA;
     uniform sampler2D textureC;
    
    
    varying vec2 vUv;

	 //vec3 color = vec3(1.0, 1.0, 0.0);         //local variable red

	void main() {
        
        vec4 colorA = texture2D(textureA, vUv);
        vec4 colorC = texture2D(textureC, vUv);
		gl_FragColor =  mix (colorA, colorC, abs(sin (time)));

	}`
};

Shaders.BasicShader9B1 = {

	name: 'BasicShader9B1', //for debugging

	uniforms: {

		'time': { type: 'f', value: 0.0 },
        
        'textureB' : {value: null}
	},
	
	vertexShader: 
	
	`uniform float time;

	varying vec2  vUv;

	void main() {
		vec3 pos = position;
       	vUv = uv;
		gl_Position = projectionMatrix * modelViewMatrix * vec4( pos, 1.0 );

	}`,
	fragmentShader:

	`uniform sampler2D textureB;
    
    
    varying vec2 vUv;

	 //vec3 color = vec3(1.0, 1.0, 0.0);         //local variable red

	void main() {
        
        vec4 colorB = texture2D(textureB, vUv);
   
		gl_FragColor = colorB;

	}`
};