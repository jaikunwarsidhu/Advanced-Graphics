//Jaikunwar Sidhu
//301055060

let Renderer, Scne, Camera, OrbitControl;
let Radius = 5, speed = 0.005, height = 25, Angle=0;

let AmbientLight, SpotLight, PointLight, DirectionLight,
 R_AreaLight, SemiSphereLight;
const color = 0xF08080;


function init(){
    Scne = new THREE.Scene(); //Scene 
    Renderer = new THREE.WebGLRenderer({ antialias: true }); //newRenderer   
    Renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    Renderer.outputEncoding = THREE.sRGBEncoding;   
    Renderer.setPixelRatio(window.devicePixelRatio);
    Renderer.setClearColor( 0x000000 ); //Background or page color
    Renderer.setSize( window.innerWidth, window.innerHeight );
    document.body.appendChild( Renderer.domElement );
    Renderer.shadowMap.enabled = true; 
}

function createGeometry(){
    Scne.add( new THREE.AxesHelper(20) );

    
    let planeGeo = new THREE.PlaneBufferGeometry(50, 250);
    let planeMat = new THREE.MeshLambertMaterial({ color: 0xFFFFFF });
    let planeMesh = new THREE.Mesh( planeGeo, planeMat );
    planeMesh.receiveShadow=true;     
    planeMesh.rotation.x = -0.5 * Math.PI;
    Scne.add( planeMesh );

    geo = new THREE.BoxGeometry( 10, 1, 10 );
    mat = new THREE.MeshPhongMaterial({ color: 0x808000 });
    mesh = new THREE.Mesh( geo, mat );
    mesh.position.set(-20, 5, 10);
    mesh.castShadow=true; 
    mesh.receiveShadow = true;
    Scne.add( mesh );

    geo = new THREE.SphereBufferGeometry(4, 50, 10);
    mat = new THREE.MeshStandardMaterial({ color: 0x008000 });
    mesh = new THREE.Mesh( geo, mat );
    mesh.position.set(15, 10, 0);
    mesh.castShadow = true; 
    mesh.receiveShadow = true;
    Scne.add( mesh );
}

function createCyanBall(){
    cyanGeo = new THREE.SphereBufferGeometry(1, 50, 50);
    cyanMat = new THREE.MeshStandardMaterial({color : 0x000066});
    cyanBall = new THREE.Mesh(cyanGeo, cyanMat);
    return cyanBall;
}


function setupCameraAndLight(){
    


    Camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 100 );
    Camera.position.set( 50, 50, 50 );
    Camera.lookAt( Scne.position );

    OrbitControl = new THREE.OrbitControls( Camera, Renderer.domElement );

    AmbientLight = new THREE.AmbientLight( color, 1);
    AmbientLight.position.set(15, 30, -15)
    AmbientLight.add(createCyanBall());
    Scne.add(AmbientLight);

    SpotLight = new THREE.SpotLight(color, 1);
    SpotLight.castShadow = true;
    SpotLight.position.set(-15, 30, 15);
    SpotLight.add(createCyanBall());
    Scne.add(SpotLight);


    PointLight = new THREE.PointLight(color, 1);
    PointLight.castShadow = true;
    PointLight.position.set(15, 10, 15);
    PointLight.add(createCyanBall());
    Scne.add(PointLight);
;

    DirectionLight = new THREE.DirectionalLight(color, 1);
    DirectionLight.castShadow = true;
    DirectionLight.position.set(10, 40, 10);
    DirectionLight.add(createCyanBall());
    Scne.add(DirectionLight);
    
    R_AreaLight = new THREE.RectAreaLight(color, 1, 15, 30);
    R_AreaLight.position.set(0, 20, 0);
    R_AreaLight.rotation.y = -0.5 * Math.PI;
    R_AreaLight.rotation.x = -0.5 * Math.PI;
    R_AreaLight.add(createCyanBall());
    Scne.add(R_AreaLight);


    SemiSphereLight = new THREE.HemisphereLight(color, 0xb97a20, 1);
    SemiSphereLight.position.set(-10, 30, 10);
    SemiSphereLight.add(createCyanBall());
    Scne.add(SemiSphereLight);
    
    
}

function setupDatGui(){
    let controls = new function(){
        
    };
    let gui = new dat.GUI();
    let A_Light = gui.addFolder('Ambient Light');
    A_Light.addColor(new ColorGUIHelper(AmbientLight, 'color'), 'value').name('Color');
    A_Light.add(AmbientLight, 'intensity', 0, 5, 0.05).name('Intensity');
    A_Light.add(AmbientLight, 'visible').name('Light Switch');

    let spot = gui.addFolder('Spot Light');
    spot.addColor(new ColorGUIHelper(SpotLight, 'color'), 'value').name('Color');
    spot.add(SpotLight, 'intensity', 0, 5, 0.05).name('Intensity');
    spot.add(SpotLight, 'visible').name('Light Switch');

    let point = gui.addFolder('Point Light');
    point.addColor(new ColorGUIHelper(PointLight, 'color'), 'value').name('Color');
    point.add(PointLight, 'intensity', 0, 5, 0.05).name('Intensity');
    point.add(PointLight, 'visible').name('Light Switch');

    let R_areaLight = gui.addFolder('Rect Area Light');
    R_areaLight.addColor(new ColorGUIHelper(R_AreaLight, 'color'), 'value').name('Color');
    R_areaLight.add(R_AreaLight, 'intensity', 0, 10, 0.05).name('Intensity');
    R_areaLight.add(R_AreaLight, 'visible').name('Light Switch');

    let Semi = gui.addFolder('Semi Sphere Light');
    Semi.addColor(new ColorGUIHelper(SemiSphereLight, 'color'), 'value').name('Sky Color');
    Semi.addColor(new ColorGUIHelper(SemiSphereLight, 'groundColor'), 'value').name('Ground Color');
    Semi.add(SemiSphereLight, 'intensity', 0, 5, 0.05).name('Intensity');
    Semi.add(SemiSphereLight, 'visible').name('Light Switch');
  
    let D_Light = gui.addFolder('Directional Light');
    D_Light.addColor(new ColorGUIHelper(DirectionLight, 'color'), 'value').name('Color');
    D_Light.add(DirectionLight, 'intensity', 0, 5, 0.05).name('Intensity');
    D_Light.add(DirectionLight, 'visible').name('Light Switch');


}

function render(){
    requestAnimationFrame( render );
    OrbitControl.update();
    Renderer.render( Scne, Camera );
}

window.onload = () => {
    init();
    setupCameraAndLight();
    createGeometry();
    setupDatGui();
    render();
}


class ColorGUIHelper {
    constructor(object, prop) {
      this.object = object;
      this.prop = prop;
    }
    get value() {
      return `#${this.object[this.prop].getHexString()}`;
    }
    set value(hexString) {
      this.object[this.prop].set(hexString);
    }
  }